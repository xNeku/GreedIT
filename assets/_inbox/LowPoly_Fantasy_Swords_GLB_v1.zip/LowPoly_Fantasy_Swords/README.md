# Low Poly Fantasy Swords — 100 Pack

A collection of **100 unique low-poly fantasy swords** with crisp pixel-art textures, organized across **10 themed wings (10 swords each)** — spanning nimble daggers & stilettos (`0.47m`), versatile arming swords, sabres & katanas, and towering greatswords & nodachis (`1.76m`). Every mesh is 100% watertight/manifold (`0` ngons, `0` non-manifold edges, `0` loose vertices) with explicit pixel-aligned UVs and bespoke **128x128** (plus **64x64** retro) Bayer-dithered textures. Light enough for mobile, VR and retro-style games.


## Summary Stats

- **Total Swords**: 100 unique meshes across 10 themed wing collections
- **Total Geometry**: 13,177 verts / 14,635 faces / 23,890 triangles (102-464 tris per sword, avg 238.9 tris)
- **Scale Range**: `0.47m` (compact daggers/dirks) to `1.76m` (colossal zweihanders & nodachis), metric scale (`1 unit = 1m`)
- **Pivot & Orientation (Individual Exports)**: Grip center at `(0, 0, 0)`, blade along `+Z`, cutting edge facing `+X`
- **Textures**: 100 primary `128x128` PNGs + 100 swappable `64x64` retro PNGs (15-bit RGB555 quantized, 4x4 Bayer dithered, `Closest`/Point filtering)
- **Export Formats**: 100 individual origin-centered `.fbx`, `.glb`, and `.obj`/`.mtl` files + combined `Fantasy_Swords_All` per format

## Complete 100-Sword Catalog

| # | Wing | Asset Name | Verts | Faces | Tris | Size (X x Y x Z m) |
|---|---|---|---|---|---|---|
| 1 | `01_Legendary` | `Fantasy_Flamberge_Inferno` | 173 | 187 | 314 | 0.344 x 0.052 x 1.383 |
| 2 | `01_Legendary` | `Fantasy_Crystal_Aether` | 130 | 144 | 232 | 0.264 x 0.048 x 1.179 |
| 3 | `01_Legendary` | `Fantasy_Moonlight_Greatblade` | 146 | 160 | 264 | 0.358 x 0.052 x 1.427 |
| 4 | `01_Legendary` | `Fantasy_Sunblade_Seraph` | 256 | 264 | 464 | 0.415 x 0.052 x 1.249 |
| 5 | `01_Legendary` | `Fantasy_Bone_Reaper` | 168 | 183 | 308 | 0.321 x 0.050 x 1.287 |
| 6 | `01_Legendary` | `Fantasy_Frostbite_Glacier` | 107 | 119 | 190 | 0.335 x 0.048 x 1.268 |
| 7 | `01_Legendary` | `Fantasy_Elven_Leafblade` | 141 | 151 | 254 | 0.201 x 0.032 x 1.134 |
| 8 | `01_Legendary` | `Fantasy_Nightmare_Soulblade` | 168 | 187 | 312 | 0.367 x 0.056 x 1.439 |
| 9 | `01_Legendary` | `Fantasy_Clockwork_Gearblade` | 174 | 209 | 316 | 0.206 x 0.052 x 1.220 |
| 10 | `01_Legendary` | `Fantasy_Dragonfang_Scytheblade` | 140 | 149 | 252 | 0.382 x 0.052 x 1.351 |
| 11 | `02_Elemental_Arcane` | `Fantasy_Stormcaller_Volt` | 103 | 115 | 182 | 0.320 x 0.048 x 1.251 |
| 12 | `02_Elemental_Arcane` | `Fantasy_Obsidian_Macuahuitl` | 148 | 172 | 264 | 0.236 x 0.048 x 1.166 |
| 13 | `02_Elemental_Arcane` | `Fantasy_Tidebreaker_Coral` | 201 | 224 | 370 | 0.334 x 0.044 x 1.153 |
| 14 | `02_Elemental_Arcane` | `Fantasy_Gale_Zephyr` | 117 | 132 | 210 | 0.269 x 0.036 x 1.224 |
| 15 | `02_Elemental_Arcane` | `Fantasy_Magma_Cleaver` | 104 | 121 | 184 | 0.250 x 0.064 x 1.350 |
| 16 | `02_Elemental_Arcane` | `Fantasy_Starfall_Astral` | 179 | 191 | 334 | 0.330 x 0.048 x 1.280 |
| 17 | `02_Elemental_Arcane` | `Fantasy_Emerald_Venomfang` | 252 | 279 | 464 | 0.230 x 0.044 x 1.221 |
| 18 | `02_Elemental_Arcane` | `Fantasy_Solar_Eclipse` | 232 | 254 | 428 | 0.330 x 0.048 x 1.414 |
| 19 | `02_Elemental_Arcane` | `Fantasy_Quartz_Prism` | 196 | 210 | 364 | 0.225 x 0.040 x 1.184 |
| 20 | `02_Elemental_Arcane` | `Fantasy_Sandstorm_Khopesh` | 124 | 141 | 224 | 0.229 x 0.040 x 1.090 |
| 21 | `03_Dark_Gothic` | `Fantasy_Bloodmoon_Vampire` | 150 | 168 | 268 | 0.404 x 0.048 x 1.378 |
| 22 | `03_Dark_Gothic` | `Fantasy_Soulreaver_Wraith` | 151 | 161 | 274 | 0.288 x 0.048 x 1.326 |
| 23 | `03_Dark_Gothic` | `Fantasy_Executioner_Greatslab` | 142 | 164 | 256 | 0.378 x 0.059 x 1.299 |
| 24 | `03_Dark_Gothic` | `Fantasy_Plague_Blightblade` | 213 | 232 | 402 | 0.230 x 0.052 x 1.176 |
| 25 | `03_Dark_Gothic` | `Fantasy_Abyssal_Tentacle` | 143 | 152 | 258 | 0.279 x 0.052 x 1.276 |
| 26 | `03_Dark_Gothic` | `Fantasy_Lich_Phylactery` | 139 | 151 | 242 | 0.291 x 0.048 x 1.349 |
| 27 | `03_Dark_Gothic` | `Fantasy_Hellhound_Sawblade` | 133 | 145 | 238 | 0.316 x 0.056 x 1.364 |
| 28 | `03_Dark_Gothic` | `Fantasy_Shadow_Daggerblade` | 159 | 172 | 298 | 0.215 x 0.032 x 1.149 |
| 29 | `03_Dark_Gothic` | `Fantasy_Gargoyle_Stoneblade` | 138 | 154 | 248 | 0.361 x 0.056 x 1.340 |
| 30 | `03_Dark_Gothic` | `Fantasy_Iron_Maiden_Thorn` | 139 | 155 | 254 | 0.295 x 0.044 x 1.272 |
| 31 | `04_Royal_Mythic` | `Fantasy_Excalibur_Sovereign` | 138 | 160 | 248 | 0.382 x 0.052 x 1.373 |
| 32 | `04_Royal_Mythic` | `Fantasy_Paladin_Crusader` | 158 | 184 | 280 | 0.351 x 0.060 x 1.428 |
| 33 | `04_Royal_Mythic` | `Fantasy_Valkyrie_Wingblade` | 161 | 168 | 282 | 0.383 x 0.044 x 1.235 |
| 34 | `04_Royal_Mythic` | `Fantasy_Dwarven_Runehammer` | 120 | 132 | 216 | 0.307 x 0.056 x 1.165 |
| 35 | `04_Royal_Mythic` | `Fantasy_Fey_Butterfly` | 171 | 177 | 306 | 0.297 x 0.040 x 1.149 |
| 36 | `04_Royal_Mythic` | `Fantasy_Druid_Briarwood` | 145 | 162 | 266 | 0.292 x 0.052 x 1.224 |
| 37 | `04_Royal_Mythic` | `Fantasy_Phoenix_Plume` | 133 | 142 | 230 | 0.376 x 0.048 x 1.315 |
| 38 | `04_Royal_Mythic` | `Fantasy_Griffin_Talon` | 127 | 138 | 230 | 0.238 x 0.044 x 1.238 |
| 39 | `04_Royal_Mythic` | `Fantasy_Titan_Colossus` | 116 | 134 | 208 | 0.324 x 0.072 x 1.540 |
| 40 | `04_Royal_Mythic` | `Fantasy_Celestial_Halberd_Sword` | 177 | 192 | 330 | 0.240 x 0.044 x 1.578 |
| 41 | `05_Eastern_Exotic` | `Fantasy_Oni_Kanabo_Blade` | 134 | 157 | 248 | 0.189 x 0.085 x 1.470 |
| 42 | `05_Eastern_Exotic` | `Fantasy_Sakura_Blossom` | 142 | 175 | 244 | 0.130 x 0.097 x 1.170 |
| 43 | `05_Eastern_Exotic` | `Fantasy_Jade_Emperor_Jian` | 137 | 155 | 246 | 0.200 x 0.044 x 1.275 |
| 44 | `05_Eastern_Exotic` | `Fantasy_Kitsune_NineTail` | 148 | 157 | 260 | 0.293 x 0.040 x 1.239 |
| 45 | `05_Eastern_Exotic` | `Fantasy_Magitek_Laserblade` | 140 | 160 | 244 | 0.230 x 0.064 x 1.348 |
| 46 | `05_Eastern_Exotic` | `Fantasy_Alchemist_Vialblade` | 200 | 238 | 360 | 0.250 x 0.067 x 1.243 |
| 47 | `05_Eastern_Exotic` | `Fantasy_Golem_Crystal_Club` | 134 | 152 | 244 | 0.302 x 0.068 x 1.317 |
| 48 | `05_Eastern_Exotic` | `Fantasy_Chitin_Mantis` | 113 | 128 | 202 | 0.367 x 0.044 x 1.121 |
| 49 | `05_Eastern_Exotic` | `Fantasy_Pirate_Cursed_Cutlass` | 187 | 220 | 346 | 0.259 x 0.052 x 1.102 |
| 50 | `05_Eastern_Exotic` | `Fantasy_Chronos_Hourglass` | 194 | 220 | 340 | 0.320 x 0.048 x 1.389 |
| 51 | `06_High_Kingdom_Knights` | `Fantasy_Silverhand_Bastard` | 78 | 88 | 136 | 0.298 x 0.044 x 1.179 |
| 52 | `06_High_Kingdom_Knights` | `Fantasy_Lionheart_Greatsword` | 158 | 184 | 280 | 0.426 x 0.064 x 1.601 |
| 53 | `06_High_Kingdom_Knights` | `Fantasy_Templar_Estoc` | 81 | 89 | 142 | 0.290 x 0.044 x 1.223 |
| 54 | `06_High_Kingdom_Knights` | `Fantasy_Royal_Kriegsmesser` | 150 | 159 | 284 | 0.241 x 0.055 x 1.360 |
| 55 | `06_High_Kingdom_Knights` | `Fantasy_Azure_Cavalier` | 140 | 147 | 256 | 0.197 x 0.084 x 1.112 |
| 56 | `06_High_Kingdom_Knights` | `Fantasy_Gilded_Estoc_Rose` | 85 | 89 | 146 | 0.152 x 0.032 x 0.529 |
| 57 | `06_High_Kingdom_Knights` | `Fantasy_Cathedral_Claymore` | 146 | 160 | 272 | 0.430 x 0.060 x 1.663 |
| 58 | `06_High_Kingdom_Knights` | `Fantasy_Herald_Broadsword` | 102 | 118 | 180 | 0.266 x 0.040 x 1.050 |
| 59 | `06_High_Kingdom_Knights` | `Fantasy_Vanguard_Falchion` | 108 | 119 | 200 | 0.169 x 0.044 x 1.007 |
| 60 | `06_High_Kingdom_Knights` | `Fantasy_Sovereign_Zweihander` | 130 | 144 | 236 | 0.500 x 0.055 x 1.760 |
| 61 | `07_Arcane_Enchanted` | `Fantasy_Sapphire_Spellblade` | 172 | 188 | 320 | 0.379 x 0.048 x 1.542 |
| 62 | `07_Arcane_Enchanted` | `Fantasy_Amber_Sunfire` | 157 | 169 | 298 | 0.150 x 0.048 x 1.104 |
| 63 | `07_Arcane_Enchanted` | `Fantasy_Amethyst_Enchanter` | 91 | 99 | 162 | 0.148 x 0.032 x 0.471 |
| 64 | `07_Arcane_Enchanted` | `Fantasy_Opal_Mirage` | 100 | 111 | 184 | 0.231 x 0.037 x 1.052 |
| 65 | `07_Arcane_Enchanted` | `Fantasy_Runesmith_Broadblade` | 82 | 94 | 144 | 0.356 x 0.056 x 1.543 |
| 66 | `07_Arcane_Enchanted` | `Fantasy_Mercury_Quicksilver` | 99 | 110 | 182 | 0.145 x 0.030 x 0.506 |
| 67 | `07_Arcane_Enchanted` | `Fantasy_Jade_Lotus_Sabre` | 128 | 141 | 244 | 0.167 x 0.063 x 1.083 |
| 68 | `07_Arcane_Enchanted` | `Fantasy_Prism_Lancer` | 118 | 126 | 220 | 0.164 x 0.032 x 0.566 |
| 69 | `07_Arcane_Enchanted` | `Fantasy_Solstice_Blade` | 175 | 187 | 326 | 0.294 x 0.036 x 1.145 |
| 70 | `07_Arcane_Enchanted` | `Fantasy_Astral_Comet` | 94 | 103 | 168 | 0.266 x 0.044 x 1.197 |
| 71 | `08_Ancient_Mythic_Empires` | `Fantasy_Spartan_Kopis` | 75 | 80 | 138 | 0.114 x 0.032 x 0.858 |
| 72 | `08_Ancient_Mythic_Empires` | `Fantasy_Bronze_Aegis_Xiphos` | 65 | 71 | 114 | 0.144 x 0.038 x 0.660 |
| 73 | `08_Ancient_Mythic_Empires` | `Fantasy_Pharaoh_Sun_Jian` | 105 | 117 | 190 | 0.198 x 0.033 x 0.560 |
| 74 | `08_Ancient_Mythic_Empires` | `Fantasy_Celtic_Leaf_Greatsword` | 123 | 127 | 230 | 0.383 x 0.044 x 1.588 |
| 75 | `08_Ancient_Mythic_Empires` | `Fantasy_Persian_Shamshir` | 101 | 110 | 186 | 0.330 x 0.026 x 1.063 |
| 76 | `08_Ancient_Mythic_Empires` | `Fantasy_Viking_Ulfberht` | 78 | 86 | 136 | 0.192 x 0.036 x 0.987 |
| 77 | `08_Ancient_Mythic_Empires` | `Fantasy_Byzantine_Spathion` | 114 | 136 | 208 | 0.126 x 0.052 x 1.076 |
| 78 | `08_Ancient_Mythic_Empires` | `Fantasy_Atlantean_Tridentblade` | 134 | 150 | 248 | 0.299 x 0.048 x 1.170 |
| 79 | `08_Ancient_Mythic_Empires` | `Fantasy_Babylon_Lapis_Sabre` | 70 | 73 | 124 | 0.230 x 0.036 x 1.020 |
| 80 | `08_Ancient_Mythic_Empires` | `Fantasy_Valkyrie_Norse_Seax` | 65 | 80 | 114 | 0.064 x 0.028 x 0.600 |
| 81 | `09_Shadow_Gothic_Orders` | `Fantasy_Raven_Feather_Estoc` | 59 | 63 | 102 | 0.159 x 0.028 x 0.506 |
| 82 | `09_Shadow_Gothic_Orders` | `Fantasy_Obsidian_Monolith` | 76 | 82 | 132 | 0.330 x 0.056 x 1.680 |
| 83 | `09_Shadow_Gothic_Orders` | `Fantasy_Dusk_Reaper_Falchion` | 108 | 119 | 200 | 0.198 x 0.044 x 1.127 |
| 84 | `09_Shadow_Gothic_Orders` | `Fantasy_Crimson_Inquisitor` | 88 | 100 | 156 | 0.410 x 0.044 x 1.577 |
| 85 | `09_Shadow_Gothic_Orders` | `Fantasy_Ashen_Knight_Longsword` | 63 | 67 | 110 | 0.294 x 0.044 x 1.197 |
| 86 | `09_Shadow_Gothic_Orders` | `Fantasy_Nocturne_Sabre` | 67 | 74 | 118 | 0.156 x 0.032 x 0.629 |
| 87 | `09_Shadow_Gothic_Orders` | `Fantasy_Brimstone_Greatsword` | 82 | 94 | 144 | 0.370 x 0.064 x 1.637 |
| 88 | `09_Shadow_Gothic_Orders` | `Fantasy_Crypt_Warden_Claymore` | 114 | 128 | 208 | 0.440 x 0.059 x 1.675 |
| 89 | `09_Shadow_Gothic_Orders` | `Fantasy_Gilded_Mourner` | 111 | 123 | 198 | 0.398 x 0.040 x 1.628 |
| 90 | `09_Shadow_Gothic_Orders` | `Fantasy_Silver_Vampire_Hunter` | 118 | 136 | 208 | 0.319 x 0.048 x 1.206 |
| 91 | `10_Eastern_Artisan_Relics` | `Fantasy_Imperial_Tachi` | 113 | 134 | 206 | 0.156 x 0.070 x 1.245 |
| 92 | `10_Eastern_Artisan_Relics` | `Fantasy_Moon_Nodachi` | 124 | 145 | 228 | 0.185 x 0.078 x 1.762 |
| 93 | `10_Eastern_Artisan_Relics` | `Fantasy_Cloud_Dao` | 124 | 139 | 236 | 0.176 x 0.076 x 1.054 |
| 94 | `10_Eastern_Artisan_Relics` | `Fantasy_Bamboo_Shinobi` | 67 | 74 | 114 | 0.059 x 0.051 x 0.585 |
| 95 | `10_Eastern_Artisan_Relics` | `Fantasy_Lotus_Hook_Sabre` | 105 | 124 | 194 | 0.101 x 0.044 x 0.490 |
| 96 | `10_Eastern_Artisan_Relics` | `Fantasy_Storm_Steel_Jian` | 83 | 91 | 150 | 0.185 x 0.040 x 1.110 |
| 97 | `10_Eastern_Artisan_Relics` | `Fantasy_Copper_Artificer` | 118 | 136 | 212 | 0.157 x 0.040 x 0.643 |
| 98 | `10_Eastern_Artisan_Relics` | `Fantasy_Ivory_Palace_Sabre` | 126 | 145 | 228 | 0.243 x 0.068 x 1.061 |
| 99 | `10_Eastern_Artisan_Relics` | `Fantasy_Emerald_Corsair` | 126 | 143 | 232 | 0.207 x 0.067 x 0.958 |
| 100 | `10_Eastern_Artisan_Relics` | `Fantasy_Aurelia_Grandblade` | 240 | 266 | 448 | 0.468 x 0.056 x 1.736 |

## Engine Import Tips

- Set texture filtering to **Point / Nearest Neighbor** (disable mipmaps or use nearest mip filtering).
- Keep materials matte/painterly (`Roughness ~0.78`, `Metallic 0.0`) so painted reflections, runes, and Bayer dithering stay razor-sharp.
- Blender files use `+Z` up; the `.glb` files are `+Y` up as glTF requires (importers convert automatically).
- For an even chunkier retro look, point a sword's material at its `Textures/64x64_Retro/*_64.png` instead: the UVs are the same.
- The `.obj` files find their textures through `../../Textures/128x128/`, so keep the folders together.

## Files

- `Exports/GLB/` one `.glb` per sword (texture embedded) + `Fantasy_Swords_All.glb`
- `Exports/FBX/` the same as `.fbx` (texture embedded)
- `Exports/OBJ/` the same as `.obj` + `.mtl`
- `Textures/128x128/` and `Textures/64x64_Retro/` 100 PNGs each
- `Fantasy_Swords_Pack.blend` every sword in one Blender file, textures packed in
- `Previews/` renders of the pack (in the OBJ_Blend zip)

## License

See `LICENSE.txt`: use the swords in any number of your own projects, commercial or not. Don't resell or redistribute them on their own.
